import { useState } from 'react'
import SharedInput from './components/SharedInput'
import Modal from './components/Modal'

function App() {
  const [form, setForm] = useState({
    username: '',
    bio: '',
    subscribe: false,
    color: 'red',
  })

  const [open, setOpen] = useState(false)
  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setOpen(true)
  }

  return (
    <div className="min-h-screen py-10">
      <div className="mx-auto max-w-2xl rounded-lg bg-white p-6 shadow">
        <h1 className="mb-6 text-2xl font-semibold">Shared Input Component Demo</h1>
        <form onSubmit={onSubmit} className="space-y-2">
          <SharedInput
            name="username"
            label="Username"
            placeholder="Enter your name"
            value={form.username}
            onChange={(v) => setForm((f) => ({ ...f, username: v }))}
          />

          <SharedInput
            type="textarea"
            name="bio"
            label="Bio"
            placeholder="Tell us about yourself"
            value={form.bio}
            onChange={(v) => setForm((f) => ({ ...f, bio: v }))}
          />

          <SharedInput
            type="checkbox"
            name="subscribe"
            label="Subscribe to newsletter"
            checked={form.subscribe}
            onChange={(v) => setForm((f) => ({ ...f, subscribe: v }))}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Favorite color</label>
            <SharedInput
              type="radio"
              name="color"
              options={["red", "green", "blue"]}
              value={form.color}
              onChange={(v) => setForm((f) => ({ ...f, color: v }))}
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-white shadow hover:bg-indigo-700"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
      <Modal title="Submission Successful" open={open} onClose={() => setOpen(false)}>
        <div className="flex items-start gap-3">
          <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-700">✓</span>
          <div>
            <p className="font-medium text-green-700">Submitted successfully</p>
            <p className="text-sm text-gray-600">Your form has been submitted. You can close this dialog.</p>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default App
