// SharedInput component - no explicit React import needed with modern JSX transform

type BaseProps = {
  name: string
  label?: string
  className?: string
}

type TextLike = BaseProps & {
  type?: 'text' | 'email' | 'password' | 'number'
  placeholder?: string
  value: string | number
  onChange: (value: string) => void
}

type Textarea = BaseProps & {
  type: 'textarea'
  placeholder?: string
  value: string
  onChange: (value: string) => void
}

type Checkbox = BaseProps & {
  type: 'checkbox'
  checked: boolean
  onChange: (checked: boolean) => void
}

type Radio = BaseProps & {
  type: 'radio'
  options: string[]
  value?: string
  onChange: (value: string) => void
}

export type SharedInputProps = TextLike | Textarea | Checkbox | Radio

export function SharedInput(props: SharedInputProps) {
  const { label, name, className } = props

  return (
    <div className={`mb-4 ${className ?? ''}`}>
      {label && props.type !== 'checkbox' && (
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">
          {label}
        </label>
      )}

      {(!('type' in props) || props.type === 'text' || props.type === 'email' || props.type === 'password' || props.type === 'number') && (
        <input
          id={name}
          name={name}
          type={(props as TextLike).type ?? 'text'}
          value={(props as TextLike).value as any}
          onChange={(e) => (props as TextLike).onChange(e.target.value)}
          placeholder={(props as TextLike).placeholder}
          className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        />
      )}

      {props.type === 'textarea' && (
        <textarea
          id={name}
          name={name}
          value={(props as Textarea).value}
          onChange={(e) => (props as Textarea).onChange(e.target.value)}
          placeholder={(props as Textarea).placeholder}
          className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          rows={4}
        />
      )}

      {props.type === 'checkbox' && (
        <label className="inline-flex items-center gap-2">
          <input
            id={name}
            name={name}
            type="checkbox"
            checked={(props as Checkbox).checked}
            onChange={(e) => (props as Checkbox).onChange(e.target.checked)}
            className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
          />
          <span className="text-sm text-gray-800">{label ?? name}</span>
        </label>
      )}

      {props.type === 'radio' && (
        <div className="flex flex-wrap gap-4">
          {(props as Radio).options.map((opt) => {
            const id = `${name}-${opt}`
            return (
              <label key={opt} className="inline-flex items-center gap-2">
                <input
                  id={id}
                  type="radio"
                  name={name}
                  value={opt}
                  checked={(props as Radio).value === opt}
                  onChange={(e) => (props as Radio).onChange(e.target.value)}
                  className="h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-sm text-gray-800">{opt}</span>
              </label>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default SharedInput
