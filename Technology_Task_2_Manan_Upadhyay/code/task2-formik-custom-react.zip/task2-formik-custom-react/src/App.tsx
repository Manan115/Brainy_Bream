import { Formik, Form } from 'formik'
import * as Yup from 'yup'
import FormikInput from './components/FormikInput'
import CustomInput, { ValidationSchemas } from './components/CustomInput'
import { useState } from 'react'
import Modal from './components/Modal'

const schema = Yup.object({
  username: ValidationSchemas.username(),
  email: ValidationSchemas.email(),
  password: ValidationSchemas.password(8),
  confirmPassword: ValidationSchemas.confirmPassword(),
  phone: ValidationSchemas.phone(),
  bio: ValidationSchemas.textLength(10, 500, 'Bio'),
  age: ValidationSchemas.age(),
  website: ValidationSchemas.url(),
  role: Yup.string().required('Select a role'),
  agree: Yup.boolean().oneOf([true], 'You must agree'),
})

function App() {
  const [open, setOpen] = useState(false)
  return (
    <div className="min-h-screen py-10">
      <div className="mx-auto max-w-xl rounded-lg bg-white p-6 shadow">
        <h1 className="mb-6 text-2xl font-semibold">Formik Custom Input + Yup</h1>
        <Formik
          initialValues={{
            username: '',
            email: '',
            password: '',
            confirmPassword: '',
            phone: '',
            bio: '',
            age: '',
            website: '',
            role: '',
            agree: false,
          }}
          validationSchema={schema}
          onSubmit={() => {
            setOpen(true)
          }}
        >
          {({ isSubmitting }) => (
            <Form className="space-y-2">
              {/* Advanced CustomInput examples */}
              <CustomInput name="username" label="Username" placeholder="Enter your username" required />
              <CustomInput name="email" type="email" label="Email Address" placeholder="you@example.com" required />
              <CustomInput name="password" type="password" label="Password" placeholder="Enter your password" required passwordRules />
              <CustomInput name="confirmPassword" type="password" label="Confirm Password" placeholder="Re-enter your password" required />
              <CustomInput name="phone" type="tel" label="Phone Number" placeholder="1234567890" required />
              <CustomInput name="bio" label="Bio" placeholder="Tell us about yourself" textarea rows={4} maxLength={500} showCharCount helperText="10-500 characters" />
              <CustomInput name="age" type="number" label="Age" placeholder="Enter your age" required />
              <CustomInput name="website" type="url" label="Website" placeholder="https://example.com" />

              {/* Reuse existing FormikInput for select + checkbox */}
              <FormikInput
                name="role"
                type="select"
                label="Role"
                options={[
                  { value: 'user', label: 'User' },
                  { value: 'admin', label: 'Admin' },
                  { value: 'guest', label: 'Guest' },
                ]}
              />
              <FormikInput name="agree" type="checkbox" label="I agree to the terms" />

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-white shadow hover:bg-indigo-700 disabled:opacity-50"
                >
                  Submit
                </button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
      <Modal title="Submission Successful" open={open} onClose={() => setOpen(false)}>
        <div className="flex items-start gap-3">
          <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-700">✓</span>
          <div>
            <p className="font-medium text-green-700">Submitted successfully</p>
            <p className="text-sm text-gray-600">Your form has been submitted. You can close this dialog.</p>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default App
