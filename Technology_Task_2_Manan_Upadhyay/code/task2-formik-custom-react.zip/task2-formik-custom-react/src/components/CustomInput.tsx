import React, { useState } from 'react'
import { useField } from 'formik'
import { Eye, EyeOff, AlertCircle, CheckCircle } from 'lucide-react'
import * as Yup from 'yup'

type BaseProps = {
  name: string
  label?: string
  type?: React.HTMLInputTypeAttribute
  placeholder?: string
  required?: boolean
  helperText?: string
  showCharCount?: boolean
  maxLength?: number
  disabled?: boolean
  className?: string
  textarea?: boolean
  rows?: number
  passwordRules?: boolean
}

type InputExtraProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, 'name' | 'type' | 'placeholder' | 'disabled' | 'maxLength'>
type TextareaExtraProps = Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'name' | 'placeholder' | 'disabled' | 'maxLength' | 'rows'>

export type CustomInputProps = BaseProps & (InputExtraProps | TextareaExtraProps)

const CustomInput: React.FC<CustomInputProps> = ({
  label,
  type = 'text',
  placeholder,
  required = false,
  helperText,
  showCharCount = false,
  maxLength,
  disabled = false,
  className = '',
  textarea = false,
  rows = 4,
  passwordRules = false,
  ...props
}) => {
  const [field, meta, helpers] = useField(props.name)
  const [showPassword, setShowPassword] = useState(false)

  const hasError = meta.touched && !!meta.error
  const isValid = meta.touched && !meta.error && !!field.value
  const currentLength = (field.value?.length as number) || 0

  const inputClasses = `
    w-full px-4 py-2.5 rounded-lg border-2 transition-all duration-200
    focus:outline-none focus:ring-2 focus:ring-offset-1
    disabled:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-60
    ${hasError 
      ? 'border-red-500 focus:border-red-500 focus:ring-red-200' 
      : isValid 
        ? 'border-green-500 focus:border-green-500 focus:ring-green-200'
        : 'border-gray-300 focus:border-blue-500 focus:ring-blue-200'
    }
    ${className}
  `

  const InputElement: any = textarea ? 'textarea' : 'input'
  const inputType = type === 'password' && showPassword ? 'text' : type

  return (
    <div className="mb-6">
      {label && (
        <label
          htmlFor={props.name}
          className="mb-2 block text-sm font-semibold text-gray-700"
        >
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div className="relative">
        <InputElement
          {...field}
          {...(props as any)}
          type={textarea ? undefined : inputType}
          placeholder={placeholder}
          disabled={disabled}
          maxLength={maxLength}
          rows={textarea ? rows : undefined}
          className={inputClasses}
          aria-invalid={hasError}
          aria-describedby={
            hasError
              ? `${props.name}-error`
              : helperText
              ? `${props.name}-helper`
              : undefined
          }
          onChange={(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
            const target = e.target as HTMLInputElement
            if (target.type === 'checkbox') {
              helpers.setValue(target.checked)
            } else {
              helpers.setValue(target.value)
            }
          }}
        />

        {type === 'password' && !textarea && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 focus:outline-none"
            tabIndex={-1}
          >
            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
          </button>
        )}

        {!textarea && type !== 'password' && (
          <>
            {hasError && (
              <AlertCircle
                size={20}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-red-500"
              />
            )}
            {isValid && (
              <CheckCircle
                size={20}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-green-500"
              />
            )}
          </>
        )}
      </div>

      <div className="mt-2">
        {hasError && (
          <div
            id={`${props.name}-error`}
            role="alert"
            className="flex items-start gap-2 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700"
          >
            <AlertCircle size={14} className="mt-0.5" />
            <span className="font-medium">{meta.error as string}</span>
          </div>
        )}
        {!hasError && passwordRules && type === 'password' && (
          <PasswordRules value={field.value || ''} minLength={maxLength || 8} />
        )}
        {!hasError && !passwordRules && (helperText || (showCharCount && maxLength)) && (
          <div className="flex items-center justify-between rounded-md border border-gray-200 bg-gray-50 px-3 py-2 text-xs text-gray-600">
            <span id={`${props.name}-helper`} className="pr-3">
              {helperText}
            </span>
            {showCharCount && maxLength && (
              <span
                className={
                  currentLength > maxLength * 0.9
                    ? 'text-orange-600 font-semibold'
                    : 'text-gray-500'
                }
              >
                {currentLength}/{maxLength}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default CustomInput

function PasswordRules({ value, minLength }: { value: string; minLength: number }) {
  const rules: { label: string; satisfied: boolean }[] = [
    { label: `At least ${minLength} characters`, satisfied: value.length >= minLength },
    { label: 'One lowercase letter', satisfied: /[a-z]/.test(value) },
    { label: 'One uppercase letter', satisfied: /[A-Z]/.test(value) },
    { label: 'One number', satisfied: /[0-9]/.test(value) },
    { label: 'One special character (@$!%*?&#)', satisfied: /[@$!%*?&#]/.test(value) },
  ]
  return (
    <ul className="mt-2 space-y-1 rounded-md border border-gray-200 bg-white px-3 py-2 text-xs">
      {rules.map(r => (
        <li key={r.label} className="flex items-center gap-2">
          {r.satisfied ? (
            <CheckCircle size={14} className="text-green-600" />
          ) : (
            <AlertCircle size={14} className="text-gray-400" />
          )}
          <span className={r.satisfied ? 'text-green-700 font-medium' : 'text-gray-600'}>{r.label}</span>
        </li>
      ))}
    </ul>
  )
}

// Validation helpers (Yup)
export const ValidationSchemas = {
  required: (fieldName = 'This field') => Yup.string().required(`${fieldName} is required`),
  email: () => Yup.string().email('Invalid email address').required('Email is required'),
  password: (minLength = 8) =>
    Yup.string()
      .min(minLength, `Password must be at least ${minLength} characters`)
      .matches(/[a-z]/, 'Password must contain at least one lowercase letter')
      .matches(/[A-Z]/, 'Password must contain at least one uppercase letter')
      .matches(/[0-9]/, 'Password must contain at least one number')
      .matches(/[@$!%*?&#]/, 'Password must contain at least one special character')
      .required('Password is required'),
  confirmPassword: () =>
    Yup.string().oneOf([Yup.ref('password')], 'Passwords must match').required('Please confirm your password'),
  phone: () => Yup.string().matches(/^[0-9]{10}$/, 'Phone number must be 10 digits').required('Phone number is required'),
  url: () => Yup.string().url('Invalid URL format').required('URL is required'),
  numberRange: (min: number, max: number) =>
    Yup.number().min(min, `Must be at least ${min}`).max(max, `Must be at most ${max}`).required('This field is required'),
  textLength: (min: number, max: number, fieldName = 'This field') =>
    Yup.string()
      .min(min, `${fieldName} must be at least ${min} characters`)
      .max(max, `${fieldName} must be at most ${max} characters`)
      .required(`${fieldName} is required`),
  username: () =>
    Yup.string()
      .min(3, 'Username must be at least 3 characters')
      .max(20, 'Username must be at most 20 characters')
      .matches(/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores')
      .required('Username is required'),
  age: () => Yup.number().min(18, 'You must be at least 18 years old').max(120, 'Invalid age').required('Age is required'),
  date: () => Yup.date().max(new Date(), 'Date cannot be in the future').required('Date is required'),
  pattern: (regex: RegExp, message: string) => Yup.string().matches(regex, message).required('This field is required'),
}
