import { useField } from 'formik'
import React from 'react'

export type FormikInputProps = {
  name: string
  label?: string
  type?: 'text' | 'email' | 'password' | 'number' | 'textarea' | 'checkbox' | 'select'
  placeholder?: string
  options?: { value: string; label: string }[] // for select
  className?: string
}

export const FormikInput: React.FC<FormikInputProps> = ({ label, type = 'text', options, ...rest }) => {
  const [field, meta, helpers] = useField(rest.name)
  const id = rest.name
  const hasError = meta.touched && meta.error

  let control: React.ReactNode = null
  if (type === 'textarea') {
    control = (
      <textarea
        id={id}
        {...field}
        placeholder={rest.placeholder}
        rows={4}
        className={`w-full rounded-md border px-3 py-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 ${hasError ? 'border-red-500' : 'border-gray-300'}`}
      />
    )
  } else if (type === 'checkbox') {
    control = (
      <label className="inline-flex items-center gap-2">
        <input
          id={id}
          type="checkbox"
          checked={field.value}
          onChange={(e) => helpers.setValue(e.target.checked)}
          className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
        />
        <span className="text-sm text-gray-800">{label || rest.name}</span>
      </label>
    )
  } else if (type === 'select') {
    control = (
      <select
        id={id}
        {...field}
        className={`w-full rounded-md border px-3 py-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 ${hasError ? 'border-red-500' : 'border-gray-300'}`}
      >
        <option value="">Select...</option>
        {(options || []).map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    )
  } else {
    control = (
      <input
        id={id}
        type={type}
        {...field}
        placeholder={rest.placeholder}
        className={`w-full rounded-md border px-3 py-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 ${hasError ? 'border-red-500' : 'border-gray-300'}`}
      />
    )
  }

  return (
    <div className={`mb-6 ${rest.className || ''}`}>
      {type !== 'checkbox' && type !== 'select' && label && (
        <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
          {label}
        </label>
      )}
      {type === 'select' && label && (
        <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
          {label}
        </label>
      )}
      {control}
      {hasError && type !== 'checkbox' && (
        <div className="mt-2 flex items-start gap-2 rounded-md border border-red-200 bg-red-50 px-3 py-2">
          <span className="text-red-600 text-xs font-medium">{meta.error}</span>
        </div>
      )}
    </div>
  )
}

export default FormikInput