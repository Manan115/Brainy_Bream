import PersonManager from './components/PersonManager'
import ExpenseForm from './components/ExpenseForm'
import ExpensesList from './components/ExpensesList'
import Balances from './components/Balances'

function App() {
  return (
    <div className="min-h-screen bg-gray-50 py-10">
      <div className="mx-auto max-w-6xl px-3">
        <h1 className="mb-6 text-3xl font-bold">Expenses Sharing App</h1>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="space-y-4">
            <PersonManager />
            <ExpenseForm />
          </div>
          <div className="space-y-4">
            <ExpensesList />
            <Balances />
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
