import { useSelector } from 'react-redux'
import type { RootState } from '../store'
import { computeNetBalances } from '../utils/balances'
import { formatCurrency } from '../utils/format'

export default function Balances() {
  const people = useSelector((s: RootState) => s.people)
  const expenses = useSelector((s: RootState) => s.expenses)
  const net = computeNetBalances(people, expenses)
  const totals = {
    spent: expenses.reduce((s, e) => s + e.amount, 0),
    positive: Object.values(net).filter((n) => n > 0).reduce((s, n) => s + n, 0),
    negative: Math.abs(
      Object.values(net).filter((n) => n < 0).reduce((s, n) => s + n, 0),
    ),
  }
  const maxAbs = Math.max(1, ...Object.values(net).map((n) => Math.abs(n)))

  return (
    <div className="rounded-lg bg-white p-4 shadow">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Balances</h2>
        <div className="flex items-center gap-2 text-xs">
          <span className="rounded bg-slate-100 px-2 py-1 text-slate-700">Total Spent: {formatCurrency(totals.spent)}</span>
          <span className="rounded bg-green-50 px-2 py-1 text-green-700">Credited: {formatCurrency(totals.positive)}</span>
          <span className="rounded bg-red-50 px-2 py-1 text-red-700">Owed: {formatCurrency(totals.negative)}</span>
        </div>
      </div>
      <div className="space-y-3">
        {people.map((p) => {
          const val = net[p.id] || 0
          const width = Math.round((Math.abs(val) / maxAbs) * 100)
          const positive = val > 0
          return (
            <div key={p.id} className="rounded border border-gray-200 p-3">
              <div className="flex items-center justify-between">
                <div className="min-w-24 font-medium text-gray-800">{p.name}</div>
                <div className="ml-4 flex-1">
                  <div className="relative h-2 w-full rounded bg-gray-100">
                    {val !== 0 && (
                      <div
                        className={`absolute top-0 h-2 rounded ${positive ? 'bg-green-500' : 'bg-red-500'}`}
                        style={{ width: `${width}%`, left: positive ? '0' : undefined, right: positive ? undefined : '0' }}
                      />
                    )}
                  </div>
                </div>
                <div className={`ml-4 min-w-28 text-right text-sm font-semibold ${positive ? 'text-green-600' : val < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                  {formatCurrency(val)}
                </div>
              </div>
            </div>
          )
        })}
      </div>
      <p className="mt-2 text-xs text-gray-500">Positive means the person should receive money; negative means they owe others.</p>
    </div>
  )
}
