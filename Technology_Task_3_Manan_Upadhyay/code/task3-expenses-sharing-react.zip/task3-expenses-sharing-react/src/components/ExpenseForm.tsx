import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import type { RootState } from '../store'
import { addExpense } from '../slices/expensesSlice'

export default function ExpenseForm() {
  const people = useSelector((s: RootState) => s.people)
  const dispatch = useDispatch()
  const [desc, setDesc] = useState('')
  const [amount, setAmount] = useState('')
  const [paidBy, setPaidBy] = useState('')
  const [participants, setParticipants] = useState<string[]>([])
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10))

  function toggleParticipant(id: string) {
    setParticipants((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  const canSubmit = desc.trim() && Number(amount) > 0 && paidBy && participants.length > 0

  function submit() {
    if (!canSubmit) return
    dispatch(
      addExpense({
        desc: desc.trim(),
        amount: Number(amount),
        paidBy,
        participants,
        date,
      }),
    )
    setDesc('')
    setAmount('')
    setPaidBy('')
    setParticipants([])
    setDate(new Date().toISOString().slice(0, 10))
  }

  return (
    <div className="rounded-lg bg-white p-4 shadow">
      <h2 className="mb-3 text-lg font-semibold">Add Expense</h2>
      <div className="mb-2 grid grid-cols-1 gap-3 md:grid-cols-2">
        <input
          className="rounded-md border border-gray-300 px-3 py-2"
          placeholder="Description"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
        />
        <input
          className="rounded-md border border-gray-300 px-3 py-2"
          placeholder="Amount"
          type="number"
          min={0}
          step="0.01"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <select
          className="rounded-md border border-gray-300 px-3 py-2"
          value={paidBy}
          onChange={(e) => setPaidBy(e.target.value)}
        >
          <option value="">Paid by...</option>
          {people.map((p) => (
            <option value={p.id} key={p.id}>
              {p.name}
            </option>
          ))}
        </select>
        <input
          className="rounded-md border border-gray-300 px-3 py-2"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
      </div>
      <div className="mb-3">
        <p className="mb-1 text-sm font-medium text-gray-700">Participants</p>
        <div className="flex flex-wrap gap-3">
          {people.map((p) => {
            const checked = participants.includes(p.id)
            const id = `part-${p.id}`
            return (
              <label key={p.id} className="inline-flex items-center gap-2">
                <input
                  id={id}
                  type="checkbox"
                  checked={checked}
                  onChange={() => toggleParticipant(p.id)}
                  className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span>{p.name}</span>
              </label>
            )
          })}
        </div>
      </div>
      <button
        className="rounded-md bg-indigo-600 px-4 py-2 text-white disabled:opacity-50"
        disabled={!canSubmit}
        onClick={submit}
      >
        Add Expense
      </button>
    </div>
  )
}
