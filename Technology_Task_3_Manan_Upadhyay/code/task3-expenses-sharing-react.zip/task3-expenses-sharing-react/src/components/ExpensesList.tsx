import { useDispatch, useSelector } from 'react-redux'
import type { RootState } from '../store'
import { removeExpense } from '../slices/expensesSlice'
import { formatCurrency } from '../utils/format'

export default function ExpensesList() {
  const expenses = useSelector((s: RootState) => s.expenses)
  const people = useSelector((s: RootState) => s.people)
  const dispatch = useDispatch()

  const nameFor = (id: string) => people.find((p) => p.id === id)?.name || 'Unknown'

  const total = expenses.reduce((sum, e) => sum + e.amount, 0)
  return (
    <div className="rounded-lg bg-white p-4 shadow">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold">Expenses</h2>
        <span className="text-sm rounded-md bg-indigo-50 px-2 py-1 font-medium text-indigo-700">
          Total: {formatCurrency(total)}
        </span>
      </div>
      {expenses.length === 0 && <p className="text-sm text-gray-500">No expenses yet.</p>}
      <div className="space-y-3">
        {expenses.map((ex) => {
          const share = ex.participants.length ? ex.amount / ex.participants.length : 0
          return (
            <div
              key={ex.id}
              className="group rounded-md border border-gray-200 p-3 hover:shadow-sm transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="pr-4">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-gray-900">{ex.desc}</p>
                    <span className="text-xs rounded bg-slate-100 px-2 py-0.5 text-slate-600">
                      {ex.date}
                    </span>
                  </div>
                  <p className="mt-0.5 text-sm text-gray-600">
                    {formatCurrency(ex.amount)} paid by{' '}
                    <span className="font-medium text-indigo-600">{nameFor(ex.paidBy)}</span>
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {ex.participants.map((pid) => (
                      <span
                        key={pid}
                        className="text-xs rounded-full bg-indigo-50 px-2 py-1 text-indigo-700"
                        title={`Share: ${formatCurrency(share)}`}
                      >
                        {nameFor(pid)}
                      </span>
                    ))}
                  </div>
                  {ex.participants.length > 0 && (
                    <p className="mt-2 text-[11px] text-gray-500">
                      Each participant share ≈ {formatCurrency(share)}
                    </p>
                  )}
                </div>
                <button
                  className="text-xs text-red-600 opacity-70 hover:opacity-100 hover:underline"
                  onClick={() => dispatch(removeExpense(ex.id))}
                >
                  Remove
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
