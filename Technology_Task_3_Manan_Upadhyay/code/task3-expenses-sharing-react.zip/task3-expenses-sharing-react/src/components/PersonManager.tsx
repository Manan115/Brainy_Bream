import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addPerson, removePerson } from '../slices/peopleSlice'
import type { RootState } from '../store'

export default function PersonManager() {
  const [name, setName] = useState('')
  const people = useSelector((s: RootState) => s.people)
  const dispatch = useDispatch()

  return (
    <div className="rounded-lg bg-white p-4 shadow">
      <h2 className="mb-3 text-lg font-semibold">People</h2>
      <div className="flex gap-2">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="flex-1 rounded-md border border-gray-300 px-3 py-2"
          placeholder="Add a person"
        />
        <button
          className="rounded-md bg-indigo-600 px-3 py-2 text-white disabled:opacity-50"
          onClick={() => {
            const n = name.trim()
            if (!n) return
            dispatch(addPerson(n))
            setName('')
          }}
          disabled={!name.trim()}
        >
          Add
        </button>
      </div>
      <ul className="mt-3 divide-y">
        {people.map((p) => (
          <li key={p.id} className="flex items-center justify-between py-2">
            <span>{p.name}</span>
            <button
              className="text-sm text-red-600 hover:underline"
              onClick={() => dispatch(removePerson(p.id))}
            >
              Remove
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}
