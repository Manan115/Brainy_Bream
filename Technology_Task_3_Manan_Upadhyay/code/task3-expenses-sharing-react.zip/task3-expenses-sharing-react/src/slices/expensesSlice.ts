import { createSlice, nanoid } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import type { Expense } from '../types'

const initialState: Expense[] = []

interface AddExpensePayload {
  desc: string
  amount: number
  paidBy: string
  participants: string[]
  date?: string
}

const expensesSlice = createSlice({
  name: 'expenses',
  initialState,
  reducers: {
    addExpense: {
      prepare(payload: AddExpensePayload) {
        return {
          payload: {
            id: nanoid(),
            desc: payload.desc,
            amount: payload.amount,
            paidBy: payload.paidBy,
            participants: payload.participants,
            date: payload.date || new Date().toISOString().slice(0, 10),
          } as Expense,
        }
      },
      reducer(state, action: PayloadAction<Expense>) {
        state.push(action.payload)
      },
    },
    removeExpense(state, action: PayloadAction<string>) {
      return state.filter((e) => e.id !== action.payload)
    },
  },
})

export const { addExpense, removeExpense } = expensesSlice.actions
export default expensesSlice.reducer
