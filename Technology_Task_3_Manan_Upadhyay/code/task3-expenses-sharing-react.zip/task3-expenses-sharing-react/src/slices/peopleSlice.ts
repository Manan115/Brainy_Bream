import { createSlice, nanoid } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import type { Person } from '../types'

const initialState: Person[] = []

const peopleSlice = createSlice({
  name: 'people',
  initialState,
  reducers: {
    addPerson: {
      prepare(name: string) {
        return { payload: { id: nanoid(), name } as Person }
      },
      reducer(state, action: PayloadAction<Person>) {
        state.push(action.payload)
      },
    },
    removePerson(state, action: PayloadAction<string>) {
      return state.filter((p) => p.id !== action.payload)
    },
  },
})

export const { addPerson, removePerson } = peopleSlice.actions
export default peopleSlice.reducer
