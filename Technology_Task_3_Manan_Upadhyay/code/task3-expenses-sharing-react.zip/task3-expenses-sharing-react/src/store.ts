import { configureStore } from '@reduxjs/toolkit'
import peopleReducer from './slices/peopleSlice'
import expensesReducer from './slices/expensesSlice'
import { loadState, saveState } from './utils/storage'

const preloaded = loadState()

export const store = configureStore({
  reducer: {
    people: peopleReducer,
    expenses: expensesReducer,
  },
  preloadedState: preloaded,
})

store.subscribe(() => {
  const state = store.getState()
  saveState({ people: state.people, expenses: state.expenses })
})

export type AppDispatch = typeof store.dispatch
export type RootState = ReturnType<typeof store.getState>
