export type Person = {
  id: string
  name: string
}

export type Expense = {
  id: string
  desc: string
  amount: number
  paidBy: string // person id
  participants: string[] // person ids
  date: string // ISO date
}

export type RootState = {
  people: Person[]
  expenses: Expense[]
}
