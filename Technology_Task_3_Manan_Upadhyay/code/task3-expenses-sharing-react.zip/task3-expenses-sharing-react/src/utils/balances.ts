import type { Expense, Person } from '../types'

export function computeNetBalances(people: Person[], expenses: Expense[]) {
  const net: Record<string, number> = {}
  people.forEach((p) => (net[p.id] = 0))

  for (const ex of expenses) {
    if (!ex.participants.length) continue
    const share = ex.amount / ex.participants.length
    // participants owe their share
    for (const pid of ex.participants) {
      net[pid] = (net[pid] ?? 0) - share
    }
    // payer gets full amount credit
    net[ex.paidBy] = (net[ex.paidBy] ?? 0) + ex.amount
  }

  return net
}
