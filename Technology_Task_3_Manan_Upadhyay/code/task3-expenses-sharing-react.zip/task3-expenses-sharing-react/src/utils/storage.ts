import type { Expense, Person } from '../types'

const KEY = 'expenses-sharing-state-v1'

export interface StoredState {
  people: Person[]
  expenses: Expense[]
}

export function loadState(): StoredState {
  if (typeof localStorage === 'undefined') return { people: [], expenses: [] }
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return { people: [], expenses: [] }
    const parsed = JSON.parse(raw)
    if (!parsed.people || !parsed.expenses) throw new Error('Invalid shape')
    return parsed
  } catch {
    return { people: [], expenses: [] }
  }
}

export function saveState(state: StoredState) {
  if (typeof localStorage === 'undefined') return
  try {
    localStorage.setItem(KEY, JSON.stringify(state))
  } catch {
    /* ignore */
  }
}
