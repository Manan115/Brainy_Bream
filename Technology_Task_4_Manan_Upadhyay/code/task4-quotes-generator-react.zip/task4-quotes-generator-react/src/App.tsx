import { useEffect, useMemo, useState } from 'react'
import { QueryClientProvider, useQuery } from '@tanstack/react-query'
import axios from 'axios'
import { queryClient } from './queryClient'
import QuoteCard from './components/QuoteCard'
import { loadPosts, savePosts, type QuotePost } from './utils/storage'

// The Domiadi API might return different field names. We'll normalize to {content, author}.
type Quote = { content: string; author: string }

function QuotesApp() {
  const [posts, setPosts] = useState<QuotePost[]>(() => loadPosts())

  useEffect(() => { savePosts(posts) }, [posts])

  const { data: quote, isFetching, isError, refetch } = useQuery<Quote>({
    queryKey: ['random-quote'],
    queryFn: async () => {
      const res = await axios.get('https://quotes.domiadi.com/api')
      const raw = res.data
      // Attempt common property names (Domiadi returns { id, from, quote, responseTime }).
      const content = raw.quote || raw.content || raw.text || ''
      const author = raw.from || raw.author || raw.name || raw.writer || 'Unknown'
      return { content, author }
    },
    enabled: true, // fetch once on mount
  })

  const handleNew = () => {
    refetch()
  }

  const [toast, setToast] = useState<string | null>(null)

  const handleCopy = async () => {
    if (!quote) return
    const text = `"${quote.content}" — ${quote.author}`
    try {
      await navigator.clipboard.writeText(text)
    } catch {
      // ignore clipboard errors (e.g., insecure context)
    }
    const post: QuotePost = {
      id: String(Date.now()),
      author: quote.author,
      content: quote.content,
      source: 'Domiadi API',
      createdAt: new Date().toISOString(),
    }
    setPosts((p) => [post, ...p])
    setToast('Copied to clipboard and saved as a post!')
    window.setTimeout(() => setToast(null), 1800)
  }

  const groupedByAuthor = useMemo(() => {
    const map = new Map<string, number>()
    for (const p of posts) map.set(p.author, (map.get(p.author) || 0) + 1)
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1])
  }, [posts])

  return (
    <div className="min-h-screen bg-gray-50 py-10">
      <div className="mx-auto max-w-5xl px-3">
        <h1 className="mb-6 text-3xl font-bold">Random Quotes & Posts</h1>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="relative">
            <QuoteCard quote={quote ?? null} onCopy={handleCopy} onNew={handleNew} />
            {isFetching && (
              <div className="absolute right-4 top-4 rounded bg-indigo-50 px-2 py-1 text-xs text-indigo-700">Loading…</div>
            )}
            {isError && (
              <div className="absolute right-4 top-4 rounded bg-red-50 px-2 py-1 text-xs text-red-700">Error fetching quote</div>
            )}
          </div>

          <div className="rounded-lg bg-white p-6 shadow">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold">Posts</h2>
              <span className="text-sm text-slate-600">{posts.length} saved</span>
            </div>
            {posts.length === 0 ? (
              <p className="text-sm text-gray-500">No posts yet. Copy a quote to add it here.</p>
            ) : (
              <ul className="space-y-4">
                {posts.map((p) => (
                  <li key={p.id} className="rounded border border-gray-200 p-3">
                    <blockquote className="text-gray-800">“{p.content}”</blockquote>
                    <div className="mt-1 flex items-center justify-between text-sm text-gray-600">
                      <span>— {p.author}</span>
                      <span>{new Date(p.createdAt).toLocaleString()}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {groupedByAuthor.length > 0 && (
          <div className="mt-6 rounded-lg bg-white p-6 shadow">
            <h2 className="mb-3 text-lg font-semibold">Top Authors</h2>
            <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
              {groupedByAuthor.map(([author, count]) => (
                <li key={author} className="flex items-center justify-between rounded border border-gray-200 px-3 py-2 text-sm">
                  <span>{author}</span>
                  <span className="rounded bg-indigo-50 px-2 py-0.5 text-indigo-700">{count}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {toast && (
          <div className="fixed bottom-4 right-4 rounded bg-gray-900/90 px-3 py-2 text-sm text-white shadow-lg">
            {toast}
          </div>
        )}
      </div>
    </div>
  )
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <QuotesApp />
    </QueryClientProvider>
  )
}

