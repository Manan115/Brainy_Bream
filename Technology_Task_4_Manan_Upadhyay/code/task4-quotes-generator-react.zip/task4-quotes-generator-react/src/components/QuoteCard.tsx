
type Quote = { content: string; author: string; _id?: string }

export default function QuoteCard({ quote, onCopy, onNew }: {
  quote: Quote | null
  onCopy: () => void
  onNew: () => void
}) {
  return (
    <div className="rounded-lg bg-white p-6 shadow">
      <h2 className="mb-4 text-lg font-semibold">Random Quote</h2>
      {quote ? (
        <div>
          <blockquote className="border-l-4 border-indigo-300 pl-4 text-gray-800">{quote.content}</blockquote>
          <p className="mt-2 text-right text-sm text-gray-600">— {quote.author}</p>
        </div>
      ) : (
        <p className="text-sm text-gray-500">No quote yet. Click "New Quote" to fetch one.</p>
      )}
      <div className="mt-4 flex gap-2">
        <button className="rounded-md bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700" onClick={onNew}>New Quote</button>
        <button className="rounded-md bg-slate-700 px-4 py-2 text-white hover:bg-slate-800" onClick={onCopy} disabled={!quote}>Copy to Post</button>
      </div>
    </div>
  )
}
