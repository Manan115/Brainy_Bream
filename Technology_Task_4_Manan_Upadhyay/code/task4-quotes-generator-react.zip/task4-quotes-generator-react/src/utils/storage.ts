export interface QuotePost {
  id: string
  author: string
  content: string
  source?: string
  createdAt: string
}

const KEY = 'quotes-posts-v1'

export function loadPosts(): QuotePost[] {
  if (typeof localStorage === 'undefined') return []
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return []
    return JSON.parse(raw)
  } catch {
    return []
  }
}

export function savePosts(posts: QuotePost[]) {
  if (typeof localStorage === 'undefined') return
  try {
    localStorage.setItem(KEY, JSON.stringify(posts))
  } catch {
    /* ignore */
  }
}
