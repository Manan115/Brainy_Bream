import { useMemo, useState } from 'react'
import { data, type Person } from './data.ts'
import DataTable from './components/DataTable.tsx'
import Pagination from './components/Pagination.tsx'

export default function App() {
  const pageSize = 10
  const [currentPage, setCurrentPage] = useState(1)

  const totalItems = data.length
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize))

  const pageData: Person[] = useMemo(() => {
    const start = (currentPage - 1) * pageSize
    return data.slice(start, start + pageSize)
  }, [currentPage])

  const handlePageChange = (page: number) => {
    setCurrentPage(Math.min(Math.max(page, 1), totalPages))
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-6xl px-4 py-10">
        <h1 className="mb-6 text-3xl font-bold">Paginated Table</h1>

        <div className="overflow-hidden rounded-lg bg-white shadow">
          <DataTable rows={pageData} />
        </div>

        <div className="mt-6">
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={handlePageChange}
          />
          <p className="mt-2 text-sm text-gray-600">
            Showing {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, totalItems)} of {totalItems}
          </p>
        </div>
      </div>
    </div>
  )
}
