import type { Person } from '../data'
import type { ReactNode } from 'react'

export default function DataTable({ rows }: { rows: Person[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <Th>ID</Th>
            <Th>Name</Th>
            <Th>Email</Th>
            <Th>City</Th>
            <Th>Company</Th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100 bg-white">
          {rows.map((r) => (
            <tr key={r.id} className="hover:bg-gray-50">
              <Td>{r.id}</Td>
              <Td>{r.name}</Td>
              <Td>
                <a href={`mailto:${r.email}`} className="text-indigo-600 hover:underline">
                  {r.email}
                </a>
              </Td>
              <Td>{r.city}</Td>
              <Td>{r.company}</Td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function Th({ children }: { children: ReactNode }) {
  return (
    <th scope="col" className="px-4 py-2 text-left text-xs font-semibold uppercase tracking-wider text-gray-600">
      {children}
    </th>
  )
}

function Td({ children }: { children: ReactNode }) {
  return <td className="whitespace-nowrap px-4 py-2 text-sm text-gray-800">{children}</td>
}
