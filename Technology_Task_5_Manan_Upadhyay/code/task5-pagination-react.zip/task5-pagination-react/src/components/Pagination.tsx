import type { ReactNode } from 'react'

type Props = {
  currentPage: number
  totalPages: number
  onPageChange: (page: number) => void
}

export default function Pagination({ currentPage, totalPages, onPageChange }: Props) {
  if (totalPages <= 1) return null

  const go = (p: number) => () => onPageChange(p)

  const pages = getMiddlePages(currentPage, totalPages, 3) // exactly three middle buttons

  const showLeftDots = pages[0] > 2
  const showRightDots = pages[pages.length - 1] < totalPages - 1

  return (
    <nav className="flex items-center justify-between" aria-label="Pagination">
      <div className="flex items-center gap-2">
        <PageButton disabled={currentPage === 1} onClick={go(currentPage - 1)}>
          Previous
        </PageButton>
      </div>

      <ol className="flex items-center gap-1">
        <PageNumber active={currentPage === 1} onClick={go(1)}>1</PageNumber>
        {showLeftDots && <Dots />}
        {pages.map((p) => (
          <PageNumber key={p} active={currentPage === p} onClick={go(p)}>
            {p}
          </PageNumber>
        ))}
        {showRightDots && <Dots />}
        {totalPages > 1 && (
          <PageNumber active={currentPage === totalPages} onClick={go(totalPages)}>
            {totalPages}
          </PageNumber>
        )}
      </ol>

      <div className="flex items-center gap-2">
        <PageButton disabled={currentPage === totalPages} onClick={go(currentPage + 1)}>
          Next
        </PageButton>
      </div>
    </nav>
  )
}

function getMiddlePages(current: number, total: number, count: number): number[] {
  if (total <= count + 2) {
    // no need for dots; return pages 2..total-1
    return range(2, Math.max(1, total - 1))
  }

  let start = Math.max(2, current - Math.floor(count / 2))
  let end = start + count - 1
  if (end > total - 1) {
    end = total - 1
    start = end - count + 1
  }
  // ensure we always have exactly `count` items
  if (start < 2) {
    start = 2
    end = start + count - 1
  }
  return range(start, Math.min(end, total - 1))
}

function range(start: number, end: number): number[] {
  if (end < start) return []
  return Array.from({ length: end - start + 1 }, (_, i) => start + i)
}

function PageButton({ children, onClick, disabled }: { children: ReactNode; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm text-gray-700 shadow-sm hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-50"
    >
      {children}
    </button>
  )
}

function PageNumber({ children, active, onClick }: { children: ReactNode; active?: boolean; onClick: () => void }) {
  return (
    <li>
      <button
        onClick={onClick}
        className={
          'min-w-9 rounded-md px-3 py-1.5 text-sm ' +
          (active
            ? 'bg-indigo-600 text-white shadow'
            : 'border border-gray-300 bg-white text-gray-700 hover:bg-gray-50')
        }
      >
        {children}
      </button>
    </li>
  )
}

function Dots() {
  return <li className="px-2 text-gray-500">…</li>
}
