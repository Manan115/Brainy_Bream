export type Person = {
  id: number
  name: string
  email: string
  city: string
  company: string
}

const cities = [
  'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose',
]
const companies = [
  'Acme Inc', 'Globex', 'Soylent', 'Initech', 'Umbrella', 'Stark Industries', 'Wayne Enterprises', 'Hooli', 'Wonka', 'Cyberdyne',
]

const pad = (n: number) => n.toString().padStart(3, '0')

export const data: Person[] = Array.from({ length: 100 }, (_, i) => {
  const id = i + 1
  const name = `User ${pad(id)}`
  const email = `user${id}@example.com`
  const city = cities[i % cities.length]
  const company = companies[i % companies.length]
  return { id, name, email, city, company }
})
